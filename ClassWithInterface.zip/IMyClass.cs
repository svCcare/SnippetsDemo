﻿namespace $rootnamespace$
{
	// created on $year$ $time$
    public interface $safeitemname$
    {
        public void Method();
    }
}
