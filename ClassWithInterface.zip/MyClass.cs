﻿namespace $rootnamespace$
{
	// created on $year$ $time$
    public class $safeitemname$ : I$safeitemname$
    {
        public void Method()
        {
            throw new NotImplementedException();
        }
    }
}
