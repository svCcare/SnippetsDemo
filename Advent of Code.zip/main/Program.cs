﻿using SharedTools;
using System.Diagnostics;

namespace $safeprojectname$
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var timer = new Stopwatch();
            timer.Start();

            var fileReader = new FileReader("input.txt", ReadOption.All);
			
			// program logic goes here

            Console.WriteLine($"Part 1: _ | done in: {timer.ElapsedMilliseconds}ms");

            timer.Restart();

            Console.WriteLine($"Part 2: _ | done in: {timer.ElapsedMilliseconds}ms");
        }
    }
}