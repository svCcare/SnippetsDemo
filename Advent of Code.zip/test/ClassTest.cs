using Xunit;

namespace $safeprojectname$
{
    public class ClassTest
    {
        [Theory]
        [InlineData("testInput", "expected")]
        public void ExampleTest(string testInput, string expected)
        {
            // Arrange
            var someValue = testInput;

            // Act
            someValue = expected;

            // Assert
            Assert.Equal(expected, someValue);
        }
    }
}